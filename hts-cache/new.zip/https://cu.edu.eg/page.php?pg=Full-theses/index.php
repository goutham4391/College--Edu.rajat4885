﻿
<!DOCTYPE html>
<head>
   
   <meta http-equiv="content-type" content="text/html; charset=utf-8" />
   <meta name="keywords" content="cairo university, scholarships,cairo university scholars, Education">
<meta name="description" content="The Official Portal for Cairo University on the Internet for Students and Staff ">
<meta name="author" content="Cairo University">
<meta name="copyright" content="Cairo University">
<meta name="robots" content="index, follow">
<meta http-equiv="cache-control" content="cache">
<meta http-equiv="content-language" content="en">
<meta http-equiv="revisit-after" content="1 days">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="generator" content="Cairo University" />
  
  <link href="templates/ts_barrister/favicon.ico" rel="shortcut icon" type="image/vnd.microsoft.icon" />
  <link rel="stylesheet" href="templates/ts_barrister/css/k2.css" type="text/css" />
  <link rel="stylesheet" href="templates/ts_barrister/css/bootstrap.min.css" type="text/css" />
  <link rel="stylesheet" href="templates/ts_barrister/css/bootstrap-responsive.min.css" type="text/css" />
  <link rel="stylesheet" href="plugins/system/helix/css/font-awesome.css" type="text/css" />
  <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700" type="text/css" />
  <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" type="text/css" />
  <link rel="stylesheet" href="//fonts.googleapis.com/css?family=Lora:400,700,400italic,700italic" type="text/css" />
  <link rel="stylesheet" href="plugins/system/helix/css/mobile-menu.css" type="text/css" />
  <link rel="stylesheet" href="templates/ts_barrister/css/animate.css" type="text/css" />
  <link rel="stylesheet" href="templates/ts_barrister/css/owl.carousel.css" type="text/css" />
  <link rel="stylesheet" href="templates/ts_barrister/css/template.css" type="text/css" />
  <link rel="stylesheet" href="templates/ts_barrister/css/presets/preset1.css" type="text/css" />
  <!-- <link rel="stylesheet" href="modules/mod_sp_tweet/assets/css/mod_sp_tweet.list.css" type="text/css" />  --> 
  <link rel="stylesheet" href="templates/ts_barrister/roksprocket/layouts/features/themes/showcase/showcase.css" type="text/css" />
  <link rel="stylesheet" href="media/com_acymailing/css/module_defaultc8c0.css?v=1413787262" type="text/css" />
  <link rel="stylesheet" href="templates/ts_barrister/roksprocket/layouts/mosaic/themes/default/mosaic.css" type="text/css" />
  <link rel="stylesheet" href="templates/ts_barrister/roksprocket/layouts/lists/themes/default/lists.css" type="text/css" />
  <link rel="stylesheet" href="media/com_uniterevolution2/assets/rs-plugin/css/settings.css" type="text/css" />
  <link rel="stylesheet" href="media/com_uniterevolution2/assets/rs-plugin/css/dynamic-captions.css" type="text/css" />
  <link rel="stylesheet" href="media/com_uniterevolution2/assets/rs-plugin/css/static-captions.css" type="text/css" />
  <style type="text/css">
.container{max-width:1170px}
body, p{font-family:'Source Sans Pro';}
h1, h2, h3, h4{font-family:'Roboto Slab';}
title{font-family:'Lora';}
#sp-slideshow-wrapper{background: rgb(255, 255, 255) !important; padding: 0 !important; }

#sp-main-body-wrapper{background: rgba(246, 180, 74, 0) !important; }

#sp-slideshow-wrapper{background: rgb(255, 255, 255) !important; padding: 0 !important; }

#sp-main-body-wrapper{background: rgba(246, 180, 74, 0) !important; }


#goog-gt-tt {display:none !important;}
.goog-te-banner-frame {display:none !important;}
.goog-te-menu-value:hover {text-decoration:none !important;}
body {top:0 !important;}
#google_translate_element2 {display:none!important;}

        a.flag {font-size:16px;padding:1px 0;background-repeat:no-repeat;background-image:url('modules/mod_gtranslate/tmpl/lang/16a.png');}
        a.flag:hover {background-image:url('modules/mod_gtranslate/tmpl/lang/16.png');}
        a.flag img {border:0;}
        a.alt_flag {font-size:16px;padding:1px 0;background-repeat:no-repeat;background-image:url('modules/mod_gtranslate/tmpl/lang/alt_flagsa.png');}
        a.alt_flag:hover {background-image:url('modules/mod_gtranslate/tmpl/lang/alt_flags.png');}
        a.alt_flag img {border:0;}
    
  </style>
  <script src="js/mootools-core.js" type="text/javascript"></script>
  <script src="js/core.js" type="text/javascript"></script>
  <script src="js/jquery.min.js" type="text/javascript"></script>
  <script src="js/jquery-noconflict.js" type="text/javascript"></script>
  <script src="js/jquery-migrate.min.js" type="text/javascript"></script>
  <script src="js/k27acb.js" type="text/javascript"></script>
  <script src="js/jquery-noconflict.js" type="text/javascript"></script>
  <script src="js/bootstrap.min.js" type="text/javascript"></script>
  <script src="js/modernizr-2.6.2.min.js" type="text/javascript"></script>
  <script src="js/helix.core.js" type="text/javascript"></script>
  <script src="js/menu.js" type="text/javascript"></script>
  <script src="js/custom.js" type="text/javascript"></script>
  <script src="js/smoothscroll.js" type="text/javascript"></script>
  <script src="js/owl.carousel.js" type="text/javascript"></script>
  <script src="js/mootools-mobile.js" type="text/javascript"></script>
  <script src="js/rokmediaqueries.js" type="text/javascript"></script>
  <script src="js/roksprocket.js" type="text/javascript"></script>
  <script src="js/moofx.js" type="text/javascript"></script>
  <script src="js/features.js" type="text/javascript"></script>
  <script src="js/showcase.js" type="text/javascript"></script>
  <script src="js/acymailing_module6ed4.js?v=480" type="text/javascript"></script>
  <script src="js/roksprocket.request.js" type="text/javascript"></script>
  <script src="js/mosaic.js" type="text/javascript"></script>
  <script src="js/mosaic.js" type="text/javascript"></script>
  <script src="js/mootools-more.js" type="text/javascript"></script>
  <script src="js/lists.js" type="text/javascript"></script>
  <script src="js/lists.js" type="text/javascript"></script>
  <script src="js/jquery.themepunch.tools.min.js" type="text/javascript"></script>
  <script src="js/jquery.themepunch.revolution.min.js" type="text/javascript"></script>
  <script type="text/javascript" src="js/fitvids.js"></script>
  <script type="text/javascript">
spnoConflict(function($){

					function mainmenu() {
						$('.sp-menu').spmenu({
							startLevel: 0,
							direction: 'ltr',
							initOffset: {
								x: 0,
								y: 30
							},
							subOffset: {
								x: 0,
								y: 0
							},
							center: 0
						});
			}

			mainmenu();

			$(window).on('resize',function(){
				mainmenu();
			});


			});

window.addEvent('domready', function(){
		RokSprocket.instances.showcase = new RokSprocket.Showcase();
});

window.addEvent('domready', function(){
	RokSprocket.instances.showcase.attach(155, '{"animation":"fromLeft","autoplay":"0","delay":"2"}');
});

	
		
window.addEvent('domready', function(){
		RokSprocket.instances.mosaic = new RokSprocket.Mosaic();
});

window.addEvent('domready', function(){
	RokSprocket.instances.mosaic.attach(132, '{"pages":2,"animations":["fade","scale","rotate","flip"],"displayed":[1,2,3,4,16,17,18,19]}');
});

window.addEvent('domready', function(){
		RokSprocket.instances.lists = new RokSprocket.Lists();
});

window.addEvent('domready', function(){
	RokSprocket.instances.lists.attach(153, '{"accordion":"1","autoplay":"0","delay":"5"}');
});

  </script>

            

</head>



<body
   class="featured homepage  ltr preset1 menu-home responsive bg hfeed clearfix">
   <div class="body-innerwrapper">

<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-WNBBKM"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','GTM-WNBBKM');</script>
<!-- End Google Tag Manager -->


      <section id="sp-top-bar-wrapper" >
         <div class="container">
            <div class="row-fluid" id="top-bar">
            
            
            
                 <div id="sp-info" class="span7" style="padding-left:20px;" >
                  <div class="custom call">
                   <ul class="top-info">
		 	<li><a href="./Home" title="Home">Home</a></li>
		 			 	<li><a href="./Agenda" title="CU Calendar">CU Calendar</a></li>
		 			 	<li><a href="./Links" title="CU Links">CU Links</a></li>
		 			 	<li><a href="./Contacts" title="Contacts">Contacts</a></li>
		 			 	<li><a href="./email" title="CU Mail">CU Mail</a></li>
		 	        
          <li><a href="./Search">Search</a></li>
                     </ul>
                    
                  </div>
               </div>
               
               
               <div id="sp-top-social" class="span5">
                  <div class="custom top-social-icons">
                     <div class="clearfix" style="direction:ltr;float:right;">
                     
                     <a class="social fb" href="https://www.facebook.com/cu.edu.eg" target="_blank" title="Official Facebook Page of Cairo Univeristy"> <i style="" class="icon-facebook "></i></a>
                     <a class="social twt" href="https://twitter.com/CairoUniv"  target="_blank" title="Official Twitter Account for Cairo University"> <i style="" class="icon-twitter "></i></a>
                     <a class="social youtube" href="https://www.youtube.com/user/TheCairoUniversity"  target="_blank" title="Official Youtube Channel of Cairo University"> <i style="" class="icon-youtube "></i></a>
                     <a class="social rss" href="./rssNews"  target="_blank" title="Rss of Cairo University"> <i style="" class="icon-rss "></i></a>
                     <a class="social linkedin " href="
                                          ar/page.php?pg=Full-theses/index.php"
                       title="الموقع باللغة العربية"> <i style="" class="icon-linkedin"></i></a>
                     
                     
                     </div>
                  </div>
               </div>
               
         
   
            </div>
         </div>
      </section>
      
      
      
      
      <header id="sp-header-wrapper" class=" ">
         <div class="container">
            <div class="row-fluid" id="header">
               <div id="sp-logo" class="span4">
                  <div class="logo-wrapper">
                     <a href="./Home"> <div style="width: 215px; height: 50px;" class="logo"></div>
                     </a>
                  </div>
               </div>
               
               
               <div id="sp-menu" class="span8">
                  <div id="sp-main-menu" class="visible-desktop">
                     <ul class="sp-menu level-0">
                    
                    
                      <li class="menu-item parent"> <a href="#" class="menu-item first parent "><span class="menu">
		    <span class="menu-title">Academic Affairs</span></span></a>
		     <div class="sp-submenu">
                              <div class="sp-submenu-wrap">
                                 <div class="sp-submenu-inner clearfix" style="width: 200px;">
                                    <div class="megacol col1 first" style="width: 200px;">
                                       <ul class="sp-menu level-1"> 		 	  <li class="menu-item"><a href="./Faculties"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Faculties & Institutes</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Academic"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Academic Services</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./UnderGraduate_Programs"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">UnderGraduate Programs</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Graduate_Programs"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Graduate  Programs</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./E_Services"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">E-Services</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./CU_Decisions"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Univeristy Decisions</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./QAU"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">QAU</span></span></a></li>
		 	 </ul>
                   </div>
                    </div>
                       </div>
                          </div>
                              </li> <li class="menu-item parent"> <a href="#" class="menu-item first parent "><span class="menu">
		    <span class="menu-title">Research</span></span></a>
		     <div class="sp-submenu">
                              <div class="sp-submenu-wrap">
                                 <div class="sp-submenu-inner clearfix" style="width: 200px;">
                                    <div class="megacol col1 first" style="width: 200px;">
                                       <ul class="sp-menu level-1"> 		 	  <li class="menu-item"><a href="./Research_Centers"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Research Centers</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./PG_Bylaws"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">PG Bylaws</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./R_projects"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Research Projects</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Publications"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Publications</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Libraries"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Libraries</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Research_Plans"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Research Plans</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Previous_Vice_Presidents"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Previous Vice Presidents</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./theses"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Theses</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Research_Awards"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Research Awards</span></span></a></li>
		 	 </ul>
                   </div>
                    </div>
                       </div>
                          </div>
                              </li> <li class="menu-item parent"> <a href="#" class="menu-item first parent "><span class="menu">
		    <span class="menu-title">Community Services</span></span></a>
		     <div class="sp-submenu">
                              <div class="sp-submenu-wrap">
                                 <div class="sp-submenu-inner clearfix" style="width: 200px;">
                                    <div class="megacol col1 first" style="width: 200px;">
                                       <ul class="sp-menu level-1"> 		 	  <li class="menu-item"><a href="./About_Community_Service"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">About Community Service</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Centers_of_Excellence"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Centers and Units</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Units_Affairs"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Units Affairs</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Enviromental_Projects"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Enviromental Projects</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Sector_Directory_Service"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Sector Directory Service</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Sector_Achievements"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Sector Achievements </span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Sector_Memorial"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Sector Memorial</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Sector_Contacts"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Contact with Sector</span></span></a></li>
		 	 </ul>
                   </div>
                    </div>
                       </div>
                          </div>
                              </li> <li class="menu-item parent"> <a href="#" class="menu-item first parent "><span class="menu">
		    <span class="menu-title">Students Life</span></span></a>
		     <div class="sp-submenu">
                              <div class="sp-submenu-wrap">
                                 <div class="sp-submenu-inner clearfix" style="width: 200px;">
                                    <div class="megacol col1 first" style="width: 200px;">
                                       <ul class="sp-menu level-1"> 		 	  <li class="menu-item"><a href="./Residences"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">On-Campus Residences</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Student_services"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Student services</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./International_student_services"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">International student</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Activities"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Activities</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./HealthCare"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">HealthCare</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Safety"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Security& Safety</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Scholarships"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Scholarships</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Agenda"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Sector News</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Students"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Students in Faculties</span></span></a></li>
		 	 </ul>
                   </div>
                    </div>
                       </div>
                          </div>
                              </li> <li class="menu-item parent"> <a href="#" class="menu-item first parent "><span class="menu">
		    <span class="menu-title">CU Staff</span></span></a>
		     <div class="sp-submenu">
                              <div class="sp-submenu-wrap">
                                 <div class="sp-submenu-inner clearfix" style="width: 200px;">
                                    <div class="megacol col1 first" style="width: 200px;">
                                       <ul class="sp-menu level-1"> 		 	  <li class="menu-item"><a href="./Facilities_and_Operations"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Facilities and Operations</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./CU_Support_Grants"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">CU Support Grants</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./HR"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">HR and Recruitments</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Medical_Services"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Medical Services</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Staff_Clubs"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Staff Clubs</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Staff_Contacts"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Staff Contacts</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Staff"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">CU Staff</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./FAQ"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">FAQ</span></span></a></li>
		 	 </ul>
                   </div>
                    </div>
                       </div>
                          </div>
                              </li> <li class="menu-item parent"> <a href="#" class="menu-item first parent "><span class="menu">
		    <span class="menu-title">Guest Services</span></span></a>
		     <div class="sp-submenu">
                              <div class="sp-submenu-wrap">
                                 <div class="sp-submenu-inner clearfix" style="width: 200px;">
                                    <div class="megacol col1 first" style="width: 200px;">
                                       <ul class="sp-menu level-1"> 		 	  <li class="menu-item"><a href="./Visiting_the_university"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Visiting the university</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Shopping"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Shopping @ CU</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Photos_Videos_Albums"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Photos and Videos Albums</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Visitors_Avaliable_Services"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Visitors Avaliable Services</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./CU_Jobs_Vacancies"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">CU Jobs Vacancies</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./CU_Certificates_Verification"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Certificates Verification</span></span></a></li>
		 	 </ul>
                   </div>
                    </div>
                       </div>
                          </div>
                              </li> <li class="menu-item parent"> <a href="#" class="menu-item first parent "><span class="menu">
		    <span class="menu-title">CU in EGYPT</span></span></a>
		     <div class="sp-submenu">
                              <div class="sp-submenu-wrap">
                                 <div class="sp-submenu-inner clearfix" style="width: 200px;">
                                    <div class="megacol col1 first" style="width: 200px;">
                                       <ul class="sp-menu level-1"> 		 	  <li class="menu-item"><a href="./Cairo_University_Leaders"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Cairo University Leaders</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Quick_Facts"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Quick Facts</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Governance"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Governance & Administration</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Policies"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">University Policies</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./Prizes"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">Honorary Degrees and Prizes</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./University_Site_Seen"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">University Site Seen</span></span></a></li>
		 			 	  <li class="menu-item"><a href="./History"
                                             class="menu-item first"><span class="menu"><span
                                             class="menu-title">CU History</span></span></a></li>
		 	 </ul>
                   </div>
                    </div>
                       </div>
                          </div>
                              </li>                          
                     </ul>
                  </div>
               </div>
            </div>
         </div>
      </header>
  <section id="sp-bottom-wrapper" class=" ">
         <div class="container">
            <div class="row-fluid" id="bottom">
      
     
                  <div id="sp-bottom2" class="span3">
                  <div class="module  firm-list">
                     <div class="mod-wrapper-flat clearfix">
                        <h3 class="header"><span>Publications</span></h3>
                        <span class="sp-badge  firm-list"></span>
                        <div class="custom firm-list">
                           <ul class="arrow">		 	<li><a href="./Books" title="CU Books">CU Books</a></li>
		 			 	<li><a href="./Journal" title="CU Journal">CU Journal</a></li>
		 			 	<li><a href="./e-periodicals" title="CU e-periodicals">CU e-periodicals</a></li>
		 	
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div class="gap"></div>
               </div>
               
                  <div id="sp-bottom2" class="span3">
                  <div class="module  firm-list">
                     <div class="mod-wrapper-flat clearfix">
                        <h3 class="header"><span>News</span></h3>
                        <span class="sp-badge  firm-list"></span>
                        <div class="custom firm-list">
                           <ul class="arrow">		 	<li><a href="CU_News_Arch" title="CU Archieving News">CU Archieving News</a></li>
		 			 	<li><a href="CU_Events_Arch" title="CU Archieving Events">CU Archieving Events</a></li>
		 			 	<li><a href="./Activity_Records" title="Faculties Archieving News">Faculties Archieving News</a></li>
		 	
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div class="gap"></div>
               </div>
               
                  <div id="sp-bottom2" class="span3">
                  <div class="module  firm-list">
                     <div class="mod-wrapper-flat clearfix">
                        <h3 class="header"><span>Visitors</span></h3>
                        <span class="sp-badge  firm-list"></span>
                        <div class="custom firm-list">
                           <ul class="arrow">		 	<li><a href="./CU_Presidents" title="Cairo University Presidents">Cairo University Presidents</a></li>
		 			 	<li><a href="./Notable_Graduates" title="Notable Graduates">Notable Graduates</a></li>
		 			 	<li><a href="./Event_Organizers" title="Event Organizers">Event Organizers</a></li>
		 	
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div class="gap"></div>
               </div>
               
                  <div id="sp-bottom2" class="span3">
                  <div class="module  firm-list">
                     <div class="mod-wrapper-flat clearfix">
                        <h3 class="header"><span>CU on Spot</span></h3>
                        <span class="sp-badge  firm-list"></span>
                        <div class="custom firm-list">
                           <ul class="arrow">		 	<li><a href="./Statistics" title="CU Statistics">CU Statistics</a></li>
		 			 	<li><a href="./CU_within_ME_Universities" title="CU within ME Universities">CU within ME Universities</a></li>
		 			 	<li><a href="./Ceremonies" title="Ceremonies">Ceremonies</a></li>
		 	
                           </ul>
                        </div>
                     </div>
                  </div>
                  <div class="gap"></div>
               </div>
                              
    
               

            </div>
         </div>
      </section>
      
      
      
      
      <footer id="sp-footer-wrapper" class=" ">
         <div class="container">
            <div class="row-fluid" id="footer">
               <div id="sp-footer1" class="span11">
                  <ul class="nav ">
                   <li class="item-151"><a href="#">Terms and Condition</a></li>
                  <li class="item-153"><a href="./Contacts">Contact Us</a></li>
                  <li class="item-153"><a href="#">Address: 1 Gamaa Street, Giza </a></li>
                   <li class="item-153"><a href="./Contacts">Postal Code: 12613 </a></li>
                  
                  </ul>
                  <span class="copyright">Copyright © 2017 Cairo University. All Rights
                  Reserved.</span>
               </div>
              <div id="sp-footer3" class="span1"><a class="sp-totop" href="javascript:;" title="Goto Top" rel="nofollow"><small>Goto Top </small><i class="icon-angle-up"></i></a></div>
</div></div></footer>	

		<a class="hidden-desktop btn btn-inverse sp-main-menu-toggler" href="#" data-toggle="collapse" data-target=".nav-collapse">
			<i class="icon-align-justify"></i>
		</a>

	<div class="hidden-desktop sp-mobile-menu nav-collapse collapse">
			<ul class="">
			<li class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-100"><a href="#" class="menu-item  parent" >
			<span class="menu">
			<span class="menu-title">Academic Affairs</span></span></a><span class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-100">
			<i class="icon-angle-right"></i><i class="icon-angle-down"></i></span>
			
			<ul class="collapse collapse-100">		 		
		 		        <li class="menu-item"><a href="./Faculties" class="menu-item" ><span class="menu"><span class="menu-title">Faculties & Institutes</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Academic" class="menu-item" ><span class="menu"><span class="menu-title">Academic Services</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./UnderGraduate_Programs" class="menu-item" ><span class="menu"><span class="menu-title">UnderGraduate Programs</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Graduate_Programs" class="menu-item" ><span class="menu"><span class="menu-title">Graduate  Programs</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./E_Services" class="menu-item" ><span class="menu"><span class="menu-title">E-Services</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./CU_Decisions" class="menu-item" ><span class="menu"><span class="menu-title">Univeristy Decisions</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./QAU" class="menu-item" ><span class="menu"><span class="menu-title">QAU</span></span></a></li>
		 			 	
		 			 	</ul></li>		
	          
	          <li class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-101"><a href="#" class="menu-item  parent" >
			<span class="menu">
			<span class="menu-title">Research</span></span></a><span class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-101">
			<i class="icon-angle-right"></i><i class="icon-angle-down"></i></span>
			
			<ul class="collapse collapse-101">		 		
		 		        <li class="menu-item"><a href="./Research_Centers" class="menu-item" ><span class="menu"><span class="menu-title">Research Centers</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./PG_Bylaws" class="menu-item" ><span class="menu"><span class="menu-title">PG Bylaws</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./R_projects" class="menu-item" ><span class="menu"><span class="menu-title">Research Projects</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Publications" class="menu-item" ><span class="menu"><span class="menu-title">Publications</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Libraries" class="menu-item" ><span class="menu"><span class="menu-title">Libraries</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Research_Plans" class="menu-item" ><span class="menu"><span class="menu-title">Research Plans</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Previous_Vice_Presidents" class="menu-item" ><span class="menu"><span class="menu-title">Previous Vice Presidents</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./theses" class="menu-item" ><span class="menu"><span class="menu-title">Theses</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Research_Awards" class="menu-item" ><span class="menu"><span class="menu-title">Research Awards</span></span></a></li>
		 			 	
		 			 	</ul></li>		
	          
	          <li class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-102"><a href="#" class="menu-item  parent" >
			<span class="menu">
			<span class="menu-title">Community Services</span></span></a><span class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-102">
			<i class="icon-angle-right"></i><i class="icon-angle-down"></i></span>
			
			<ul class="collapse collapse-102">		 		
		 		        <li class="menu-item"><a href="./About_Community_Service" class="menu-item" ><span class="menu"><span class="menu-title">About Community Service</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Centers_of_Excellence" class="menu-item" ><span class="menu"><span class="menu-title">Centers and Units</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Units_Affairs" class="menu-item" ><span class="menu"><span class="menu-title">Units Affairs</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Enviromental_Projects" class="menu-item" ><span class="menu"><span class="menu-title">Enviromental Projects</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Sector_Directory_Service" class="menu-item" ><span class="menu"><span class="menu-title">Sector Directory Service</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Sector_Achievements" class="menu-item" ><span class="menu"><span class="menu-title">Sector Achievements </span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Sector_Memorial" class="menu-item" ><span class="menu"><span class="menu-title">Sector Memorial</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Sector_Contacts" class="menu-item" ><span class="menu"><span class="menu-title">Contact with Sector</span></span></a></li>
		 			 	
		 			 	</ul></li>		
	          
	          <li class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-103"><a href="#" class="menu-item  parent" >
			<span class="menu">
			<span class="menu-title">Students Life</span></span></a><span class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-103">
			<i class="icon-angle-right"></i><i class="icon-angle-down"></i></span>
			
			<ul class="collapse collapse-103">		 		
		 		        <li class="menu-item"><a href="./Residences" class="menu-item" ><span class="menu"><span class="menu-title">On-Campus Residences</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Student_services" class="menu-item" ><span class="menu"><span class="menu-title">Student services</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./International_student_services" class="menu-item" ><span class="menu"><span class="menu-title">International student</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Activities" class="menu-item" ><span class="menu"><span class="menu-title">Activities</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./HealthCare" class="menu-item" ><span class="menu"><span class="menu-title">HealthCare</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Safety" class="menu-item" ><span class="menu"><span class="menu-title">Security& Safety</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Scholarships" class="menu-item" ><span class="menu"><span class="menu-title">Scholarships</span></span></a></li>
		 			 	
		 			 			 			 	<li class="menu-item"><a href="././Faculty-News-104.html" class="menu-item" ><span class="menu"><span class="menu-title">Sector News</span></span></a></li>
		 			 			 		
		 		        <li class="menu-item"><a href="./Students" class="menu-item" ><span class="menu"><span class="menu-title">Students in Faculties</span></span></a></li>
		 			 	
		 			 	</ul></li>		
	          
	          <li class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-104"><a href="#" class="menu-item  parent" >
			<span class="menu">
			<span class="menu-title">CU Staff</span></span></a><span class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-104">
			<i class="icon-angle-right"></i><i class="icon-angle-down"></i></span>
			
			<ul class="collapse collapse-104">		 		
		 		        <li class="menu-item"><a href="./Facilities_and_Operations" class="menu-item" ><span class="menu"><span class="menu-title">Facilities and Operations</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./CU_Support_Grants" class="menu-item" ><span class="menu"><span class="menu-title">CU Support Grants</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./HR" class="menu-item" ><span class="menu"><span class="menu-title">HR and Recruitments</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Medical_Services" class="menu-item" ><span class="menu"><span class="menu-title">Medical Services</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Staff_Clubs" class="menu-item" ><span class="menu"><span class="menu-title">Staff Clubs</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Staff_Contacts" class="menu-item" ><span class="menu"><span class="menu-title">Staff Contacts</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Staff" class="menu-item" ><span class="menu"><span class="menu-title">CU Staff</span></span></a></li>
		 			 	
		 			 			 			 	<li class="menu-item"><a href="./FAQ" class="menu-item" ><span class="menu"><span class="menu-title">FAQ</span></span></a></li>
		 			 	</ul></li>		
	          
	          <li class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-105"><a href="#" class="menu-item  parent" >
			<span class="menu">
			<span class="menu-title">Guest Services</span></span></a><span class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-105">
			<i class="icon-angle-right"></i><i class="icon-angle-down"></i></span>
			
			<ul class="collapse collapse-105">		 		
		 		        <li class="menu-item"><a href="./Visiting_the_university" class="menu-item" ><span class="menu"><span class="menu-title">Visiting the university</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Shopping" class="menu-item" ><span class="menu"><span class="menu-title">Shopping @ CU</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Photos_Videos_Albums" class="menu-item" ><span class="menu"><span class="menu-title">Photos and Videos Albums</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Visitors_Avaliable_Services" class="menu-item" ><span class="menu"><span class="menu-title">Visitors Avaliable Services</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./CU_Jobs_Vacancies" class="menu-item" ><span class="menu"><span class="menu-title">CU Jobs Vacancies</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./CU_Certificates_Verification" class="menu-item" ><span class="menu"><span class="menu-title">Certificates Verification</span></span></a></li>
		 			 	
		 			 	</ul></li>		
	          
	          <li class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-106"><a href="#" class="menu-item  parent" >
			<span class="menu">
			<span class="menu-title">CU in EGYPT</span></span></a><span class="sp-menu-toggler collapsed" data-toggle="collapse" data-target=".collapse-106">
			<i class="icon-angle-right"></i><i class="icon-angle-down"></i></span>
			
			<ul class="collapse collapse-106">		 		
		 		        <li class="menu-item"><a href="./Cairo_University_Leaders" class="menu-item" ><span class="menu"><span class="menu-title">Cairo University Leaders</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Quick_Facts" class="menu-item" ><span class="menu"><span class="menu-title">Quick Facts</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Governance" class="menu-item" ><span class="menu"><span class="menu-title">Governance & Administration</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Policies" class="menu-item" ><span class="menu"><span class="menu-title">University Policies</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./Prizes" class="menu-item" ><span class="menu"><span class="menu-title">Honorary Degrees and Prizes</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./University_Site_Seen" class="menu-item" ><span class="menu"><span class="menu-title">University Site Seen</span></span></a></li>
		 			 	
		 			 			 		
		 		        <li class="menu-item"><a href="./History" class="menu-item" ><span class="menu"><span class="menu-title">CU History</span></span></a></li>
		 			 	
		 			 	</ul></li>		
	          
	          	          </ul>   
		</div>
		        
		</div>
    </body>
</html>


<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-33011527-1']);
  _gaq.push(['_setDomainName', 'cu.edu.eg']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

<title>Cairo University</title>